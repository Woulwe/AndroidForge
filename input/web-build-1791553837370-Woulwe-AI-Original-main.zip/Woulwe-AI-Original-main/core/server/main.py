from uuid import uuid4
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Woulwe AI Core", version="0.1.0")

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: list[Message]

@app.get("/health")
def health():
    return {"status": "ok", "model": "woulwe"}

@app.post("/v1/chat")
def chat(request: ChatRequest):
    user = next((m.content for m in reversed(request.messages) if m.role == "user"), "")
    # Deliberately no third-party AI API: this is the inference seam for the future Woulwe model.
    return {
        "id": str(uuid4()),
        "model": "woulwe-0.1.0",
        "message": {
            "role": "assistant",
            "content": "Woulwe AI Core готов. Собственная модель Woulwe будет подключена к inference-слою."
        },
        "input_echo": user
    }
