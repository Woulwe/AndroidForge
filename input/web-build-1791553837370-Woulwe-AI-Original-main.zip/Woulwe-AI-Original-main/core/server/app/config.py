from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    host: str = os.getenv("WOULWE_HOST", "0.0.0.0")
    port: int = int(os.getenv("WOULWE_PORT", "8000"))
    model: str = os.getenv("WOULWE_MODEL", "woulwe")

settings = Settings()
