class WoulweModel:
    """Interface for the future trained Woulwe model."""

    name = "woulwe"
    version = "0.1.0"

    def generate(self, prompt: str) -> str:
        raise NotImplementedError("Woulwe weights are not installed yet")
