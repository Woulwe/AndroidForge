from dataclasses import dataclass, field

@dataclass
class SessionMemory:
    messages: list[dict] = field(default_factory=list)

_memory: dict[str, SessionMemory] = {}

def get_session(session_id: str) -> SessionMemory:
    return _memory.setdefault(session_id, SessionMemory())

def append(session_id: str, role: str, content: str) -> None:
    get_session(session_id).messages.append({"role": role, "content": content})
