from .model import WoulweModel
class InferenceEngine:
    def __init__(self, model=None):
        self.model=model or WoulweModel()
    def generate(self, prompt:str)->str:
        return self.model.generate(prompt)
engine=InferenceEngine()
