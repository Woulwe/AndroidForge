"""Authentication boundary.

Production implementation should use a dedicated identity database and signed tokens.
No provider-specific AI API is used here.
"""

from hashlib import sha256

def password_digest(password: str) -> str:
    return sha256(password.encode("utf-8")).hexdigest()
