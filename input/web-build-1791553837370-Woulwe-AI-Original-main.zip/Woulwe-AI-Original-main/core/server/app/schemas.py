from pydantic import BaseModel, Field
from typing import Literal
class Message(BaseModel):
    role: Literal["system","user","assistant"]
    content: str = Field(min_length=1,max_length=100000)
class ChatRequest(BaseModel):
    messages:list[Message]
    session_id:str|None=None
class ToolRequest(BaseModel):
    name:str
    arguments:dict={}
