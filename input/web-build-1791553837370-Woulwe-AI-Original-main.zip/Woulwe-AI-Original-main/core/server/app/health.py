def status(model_name:str)->dict:
    return {"status":"ok","model":model_name,"layers":["api","memory","tools","inference","model"]}
