from typing import Callable

TOOLS: dict[str, Callable] = {}

def register(name: str):
    def decorator(fn: Callable):
        TOOLS[name] = fn
        return fn
    return decorator

@register("health")
def health_tool():
    return {"status": "ok"}
