from pathlib import Path
import json
DATA=Path(__file__).resolve().parent.parent/"data"
DATA.mkdir(exist_ok=True)
def save_session(session_id:str,messages:list[dict])->None:
    (DATA/f"{session_id}.json").write_text(json.dumps(messages,ensure_ascii=False),encoding="utf-8")
def load_session(session_id:str)->list[dict]:
    p=DATA/f"{session_id}.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
