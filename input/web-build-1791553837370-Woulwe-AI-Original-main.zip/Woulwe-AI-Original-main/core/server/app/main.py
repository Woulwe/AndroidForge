from fastapi import FastAPI
from pydantic import BaseModel
from uuid import uuid4
from typing import Literal

app = FastAPI(title="Woulwe AI", version="0.2.0")

class Message(BaseModel):
    role: Literal["system","user","assistant"]
    content: str

class ChatRequest(BaseModel):
    messages: list[Message]
    session_id: str | None = None

class ChatResponse(BaseModel):
    id: str
    model: str
    message: Message
    session_id: str

@app.get("/health")
def health():
    return {"status":"ok","service":"woulwe-core","model":"woulwe"}

@app.post("/v1/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    session = req.session_id or str(uuid4())
    user = next((m.content for m in reversed(req.messages) if m.role == "user"), "")
    return ChatResponse(
        id=str(uuid4()), model="woulwe-0.2.0", session_id=session,
        message=Message(role="assistant",
            content="Woulwe Core получил сообщение. Подключение собственной Woulwe Model готово.")
    )
