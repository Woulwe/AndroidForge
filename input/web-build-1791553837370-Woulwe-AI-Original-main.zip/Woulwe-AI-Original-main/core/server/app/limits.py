import time
_hits:dict[str,list[float]]={}
def allow(key:str,limit:int=60,window:int=60)->bool:
    now=time.time()
    values=[x for x in _hits.get(key,[]) if now-x<window]
    if len(values)>=limit:return False
    values.append(now);_hits[key]=values
    return True
