from fastapi.testclient import TestClient
from app.main import app
def test_health():
    r=TestClient(app).get("/health")
    assert r.status_code==200
def test_chat():
    r=TestClient(app).post("/v1/chat",json={"messages":[{"role":"user","content":"Привет"}]})
    assert r.status_code==200
    assert r.json()["message"]["role"]=="assistant"
