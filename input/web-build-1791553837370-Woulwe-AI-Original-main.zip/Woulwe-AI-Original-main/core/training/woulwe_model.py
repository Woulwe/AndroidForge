import torch
from torch import nn

class WoulweConfig:
    def __init__(self,vocab_size=32000,dim=512,layers=8,heads=8,context=2048):
        self.vocab_size=vocab_size; self.dim=dim; self.layers=layers
        self.heads=heads; self.context=context

class CausalSelfAttention(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.qkv=nn.Linear(cfg.dim,cfg.dim*3)
        self.proj=nn.Linear(cfg.dim,cfg.dim)
        self.heads=cfg.heads
        self.dim=cfg.dim
        self.register_buffer("mask",torch.tril(torch.ones(cfg.context,cfg.context)).view(1,1,cfg.context,cfg.context))
    def forward(self,x):
        b,t,c=x.shape
        q,k,v=self.qkv(x).split(c,dim=2)
        q=q.view(b,t,self.heads,c//self.heads).transpose(1,2)
        k=k.view(b,t,self.heads,c//self.heads).transpose(1,2)
        v=v.view(b,t,self.heads,c//self.heads).transpose(1,2)
        a=(q@k.transpose(-2,-1))/(c//self.heads)**0.5
        a=a.masked_fill(self.mask[:,:,:t,:t]==0,float("-inf")).softmax(-1)
        return self.proj((a@v).transpose(1,2).contiguous().view(b,t,c))

class Block(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.n1=nn.LayerNorm(cfg.dim); self.attn=CausalSelfAttention(cfg)
        self.n2=nn.LayerNorm(cfg.dim)
        self.mlp=nn.Sequential(nn.Linear(cfg.dim,cfg.dim*4),nn.GELU(),nn.Linear(cfg.dim*4,cfg.dim))
    def forward(self,x):
        x=x+self.attn(self.n1(x)); return x+self.mlp(self.n2(x))

class WoulweLM(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg
        self.tok=nn.Embedding(cfg.vocab_size,cfg.dim)
        self.pos=nn.Embedding(cfg.context,cfg.dim)
        self.blocks=nn.ModuleList([Block(cfg) for _ in range(cfg.layers)])
        self.norm=nn.LayerNorm(cfg.dim); self.head=nn.Linear(cfg.dim,cfg.vocab_size,bias=False)
        self.head.weight=self.tok.weight
    def forward(self,ids,targets=None):
        t=ids.size(1); x=self.tok(ids)+self.pos(torch.arange(t,device=ids.device))
        for b in self.blocks:x=b(x)
        logits=self.head(self.norm(x))
        loss=None if targets is None else nn.functional.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss
