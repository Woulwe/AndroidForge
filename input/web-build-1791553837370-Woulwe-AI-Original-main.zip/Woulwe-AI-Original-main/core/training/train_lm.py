import argparse, json
from pathlib import Path
import torch
from torch.utils.data import Dataset,DataLoader
from woulwe_model import WoulweConfig,WoulweLM

class TokenDataset(Dataset):
    def __init__(self,path,context):
        self.rows=[json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]
        self.context=context
    def __len__(self): return len(self.rows)
    def __getitem__(self,i):
        ids=self.rows[i]["input_ids"][:self.context+1]
        ids=ids+[0]*(self.context+1-len(ids))
        x=torch.tensor(ids[:-1],dtype=torch.long); y=torch.tensor(ids[1:],dtype=torch.long)
        return x,y

def main():
    p=argparse.ArgumentParser(); p.add_argument("--data",required=True); p.add_argument("--out",default="checkpoints/woulwe.pt")
    p.add_argument("--steps",type=int,default=1000); p.add_argument("--batch",type=int,default=2)
    p.add_argument("--context",type=int,default=256); p.add_argument("--vocab",type=int,default=32000)
    a=p.parse_args(); device="cuda" if torch.cuda.is_available() else "cpu"
    cfg=WoulweConfig(vocab_size=a.vocab,context=a.context)
    model=WoulweLM(cfg).to(device); opt=torch.optim.AdamW(model.parameters(),lr=3e-4,weight_decay=.1)
    dl=DataLoader(TokenDataset(a.data,a.context),batch_size=a.batch,shuffle=True)
    step=0
    while step<a.steps:
        for x,y in dl:
            model.train(); _,loss=model(x.to(device),y.to(device)); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
            step+=1
            if step%50==0: print(f"step={step} loss={loss.item():.4f}")
            if step>=a.steps: break
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    torch.save({"config":cfg.__dict__,"state_dict":model.state_dict()},a.out)
    print("saved",a.out)

if __name__=="__main__": main()
