import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
source = ROOT / "dataset.example.jsonl"
output = ROOT / "prepared.example.jsonl"
rows = []
for line in source.read_text(encoding="utf-8").splitlines():
    if line.strip():
        item=json.loads(line)
        if item.get("messages"): rows.append(item)
output.write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in rows)+"\n",encoding="utf-8")
print(f"Prepared {len(rows)} examples")
