import argparse,json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(); p.add_argument("--text",required=True); p.add_argument("--vocab",required=True); p.add_argument("--out",required=True); a=p.parse_args()
    vocab={x:i for i,x in enumerate(Path(a.vocab).read_text(encoding="utf-8").splitlines())}
    unk=vocab.get(" ",0)
    lines=Path(a.text).read_text(encoding="utf-8").splitlines()
    with open(a.out,"w",encoding="utf-8") as f:
        for line in lines:
            ids=[vocab.get(ch,unk) for ch in line]
            if len(ids)>1:f.write(json.dumps({"input_ids":ids},ensure_ascii=False)+"\n")
if __name__=="__main__":main()
