"""Train a tokenizer vocabulary from plain UTF-8 text.
This intentionally produces project-owned tokenizer artifacts.
"""
import argparse
from pathlib import Path
def main():
    p=argparse.ArgumentParser(); p.add_argument("--text",required=True); p.add_argument("--out",default="tokenizer.txt"); a=p.parse_args()
    text=Path(a.text).read_text(encoding="utf-8")
    chars=sorted(set(text))
    Path(a.out).write_text("\n".join(chars),encoding="utf-8")
    print("created vocabulary entries:",len(chars))
if __name__=="__main__": main()
