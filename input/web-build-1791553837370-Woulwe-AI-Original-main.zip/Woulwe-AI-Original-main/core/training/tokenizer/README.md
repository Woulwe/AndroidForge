# Woulwe Tokenizer

Собственный tokenizer vocabulary/config будет обучаться и версионироваться вместе с моделью.
