# Woulwe Tools

Безопасный registry для search, files, calculator, browser, image, code и других инструментов. Каждый tool получает schema, permissions, timeout и журналирование.
