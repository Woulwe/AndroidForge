# Woulwe Security

Секреты через secret storage; authentication; rate limiting; sandbox для tools; validation; безопасное журналирование; веса модели не хранятся в Git.
