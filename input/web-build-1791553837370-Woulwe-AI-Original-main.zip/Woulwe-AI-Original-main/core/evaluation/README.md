# Woulwe Evaluation

Проверки: factuality, reasoning, русский язык, instruction following, safety, tool use.
