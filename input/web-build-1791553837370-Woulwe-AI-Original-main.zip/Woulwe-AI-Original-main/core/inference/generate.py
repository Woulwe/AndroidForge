import torch
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]/"training"))
from woulwe_model import WoulweConfig,WoulweLM

class LocalWoulweInference:
    def __init__(self,checkpoint,device=None):
        self.device=device or ("cuda" if torch.cuda.is_available() else "cpu")
        ckpt=torch.load(checkpoint,map_location=self.device)
        cfg=WoulweConfig(**ckpt["config"]); self.model=WoulweLM(cfg).to(self.device)
        self.model.load_state_dict(ckpt["state_dict"]); self.model.eval()
    @torch.no_grad()
    def generate(self,input_ids,max_new_tokens=64,temperature=.8):
        ids=input_ids.to(self.device)
        for _ in range(max_new_tokens):
            logits,_=self.model(ids[:,-self.model.cfg.context:])
            probs=(logits[:,-1,:]/max(temperature,.01)).softmax(-1)
            nxt=torch.multinomial(probs,1); ids=torch.cat([ids,nxt],1)
        return ids
