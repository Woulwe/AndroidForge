# Woulwe Inference

Локальный inference для собственных Woulwe checkpoints. Если checkpoint отсутствует, сервер не притворяется, что модель обучена.
