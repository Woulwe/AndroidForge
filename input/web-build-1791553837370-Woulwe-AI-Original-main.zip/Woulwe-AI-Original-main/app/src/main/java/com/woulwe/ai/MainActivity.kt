package com.woulwe.ai

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val messages = JSONArray()
    private var sessionId: String? = null
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: TextView
    private var busy = false
    private var pendingFileText = ""
    private var toolsDialog: AlertDialog? = null

    private val bgColor = Color.rgb(10, 12, 23)
    private val mutedColor = Color.rgb(158, 166, 194)
    private fun bg(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun gradient(radius: Float) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(111, 82, 255), Color.rgb(48, 133, 255))).apply { cornerRadius = radius }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(10))
            setBackgroundColor(bgColor)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(6), dp(2), dp(10)) }
        val menu = roundButton("☰", Color.rgb(29, 32, 51), 44).apply { textSize = 20f; setOnClickListener { showMainMenu(this) } }
        header.addView(menu, LinearLayout.LayoutParams(dp(44), dp(44)))
        val logo = TextView(this).apply { text = "✦"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = gradient(dp(17).toFloat()) }
        header.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(10) })
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        names.addView(TextView(this).apply { text = "Woulwe AI"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
        status = TextView(this).apply { text = "Умный помощник"; textSize = 11.5f; setTextColor(mutedColor) }
        names.addView(status)
        header.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(roundButton("＋", Color.rgb(29, 32, 51), 44).apply { textSize = 25f; setOnClickListener { resetChat() } }, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(header)
        root.addView(View(this).apply { setBackgroundColor(Color.rgb(34, 37, 57)) }, LinearLayout.LayoutParams(-1, dp(1)))

        scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; overScrollMode = View.OVER_SCROLL_NEVER }
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(1), dp(12), dp(1), dp(18)) }
        scroll.addView(chat, android.widget.FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val toolsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(10)) }
        toolsRow.addView(toolChip("⌕  Интернет") { askWebsite() })
        toolsRow.addView(toolChip("▤  Файл") { chooseFile() }, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(8) })
        toolsRow.addView(toolChip("✧  Изображение") { askImage() }, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(8) })
        toolsRow.addView(toolChip("◈  Инструменты") { showTools() }, LinearLayout.LayoutParams(-2, dp(38)).apply { leftMargin = dp(8) })
        toolsScroll.addView(toolsRow)
        root.addView(toolsScroll)

        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(7), dp(7)); background = bg(Color.rgb(27, 30, 47), dp(25).toFloat()) }
        composer.addView(roundButton("＋", Color.rgb(41, 44, 65), 42).apply { textSize = 23f; setOnClickListener { chooseFile() } }, LinearLayout.LayoutParams(dp(42), dp(42)))
        input = EditText(this).apply {
            hint = "Напиши Woulwe AI…"; textSize = 15.5f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(133, 141, 169))
            setPadding(dp(10), dp(8), dp(6), dp(8)); background = null; minHeight = dp(44); maxLines = 5
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, id, _ -> if (id == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false }
        }
        send = TextView(this).apply { text = "↑"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = gradient(dp(18).toFloat()); setOnClickListener { sendMessage() } }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(send, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(composer)
        root.addView(TextView(this).apply { text = "Woulwe AI может ошибаться — проверяй важную информацию"; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.rgb(104, 111, 139)); setPadding(0, dp(7), 0, 0) })
        val screen = android.widget.FrameLayout(this)
        screen.addView(root, android.widget.FrameLayout.LayoutParams(-1, -1))
        val splash = AiSplashView(this)
        screen.addView(splash, android.widget.FrameLayout.LayoutParams(-1, -1))
        setContentView(screen)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ if (!isFinishing && !isDestroyed) { screen.removeView(splash); splash.stop() } }, 1700L)
        restoreChat()
        updateModelStatus()
    }

    private fun roundButton(label: String, color: Int, size: Int) = TextView(this).apply {
        text = label; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = bg(color, dp(16).toFloat()); isClickable = true
    }
    private fun toolChip(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.rgb(224, 226, 246)); setPadding(dp(14), 0, dp(14), 0)
        background = bg(Color.rgb(27, 30, 48), dp(19).toFloat()); setOnClickListener { action() }
    }

    private fun showMainMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("＋  Новый чат").setOnMenuItemClickListener { resetChat(); true }
        popup.menu.add("⌕  Прочитать сайт").setOnMenuItemClickListener { askWebsite(); true }
        popup.menu.add("▤  Анализ файла").setOnMenuItemClickListener { chooseFile(); true }
        popup.menu.add("✧  Создать изображение").setOnMenuItemClickListener { askImage(); true }
        popup.menu.add("◈  Инструменты и модули").setOnMenuItemClickListener { showTools(); true }
        popup.menu.add("⚙  Настройки модели").setOnMenuItemClickListener { showModelSettings(); true }
        popup.menu.add("ℹ  О Woulwe AI").setOnMenuItemClickListener { AlertDialog.Builder(this).setTitle("Woulwe AI Original").setMessage("Локальный проект собственной модели Woulwe. Запросы чата не отправляются сторонним ИИ-провайдерам. Большие веса модели пока находятся в разработке.").setPositiveButton("Понятно", null).show(); true }
        popup.show()
    }

    private fun showTools() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(4)) }
        val items = listOf(
            Triple("⌕  Чтение сайтов", "Загрузить текст общедоступной страницы по ссылке.", 0),
            Triple("▤  Анализ файлов", "TXT, Markdown, CSV и JSON — содержание и выводы.", 1),
            Triple("✧  Генерация изображений", "Создать изображение по текстовому описанию.", 2),
            Triple("◉  Анализ данных", "Вставь таблицу или CSV в чат для анализа.", 3),
            Triple("{ }  Код и тексты", "Помощь с кодом, идеями, переводом и обучением.", 4)
        )
        items.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.rgb(27, 30, 49), dp(17).toFloat())
                setOnClickListener {
                    toolsDialog?.dismiss()
                    when (item.third) {
                        0 -> askWebsite()
                        1 -> chooseFile()
                        2 -> askImage()
                        3 -> { input.setText("Проанализируй эти данные: "); input.requestFocus() }
                        else -> { input.setText("Помоги мне с кодом или текстом: "); input.requestFocus() }
                    }
                }
            }
            card.addView(TextView(this).apply { text = item.first; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            card.addView(TextView(this).apply { text = item.second; textSize = 12f; setTextColor(mutedColor); setPadding(0, dp(5), 0, 0) })
            panel.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        toolsDialog = AlertDialog.Builder(this).setTitle("Инструменты Woulwe AI").setView(panel).setNegativeButton("Закрыть", null).create()
        toolsDialog?.show()
    }

    private fun askWebsite() {
        val field = EditText(this).apply { hint = "https://example.com"; textSize = 15f; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(mutedColor); setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.rgb(31, 34, 53), dp(15).toFloat()) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(TextView(this).apply { text = "Вставь ссылку на общедоступную текстовую страницу. Её текст будет загружен на телефон."; textSize = 13f; setTextColor(mutedColor); setPadding(0, 0, 0, dp(12)) })
        box.addView(field)
        AlertDialog.Builder(this).setTitle("Прочитать сайт").setView(box).setNegativeButton("Отмена", null)
            .setPositiveButton("Открыть и разобрать") { _, _ -> readWebsite(field.text.toString().trim()) }.show()
    }

    private fun readWebsite(url: String) {
        if (url.isBlank()) return
        val target = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        status.text = "Читаю сайт на устройстве…"; setBusy(true)
        client.newCall(Request.Builder().url(target).get().header("User-Agent", "WoulweAI-Android/1.0").build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) = runOnUiThread {
                status.text = "Не удалось открыть сайт"; setBusy(false)
                addMessage("Woulwe AI", "Не удалось загрузить страницу. Проверь ссылку и интернет-соединение.", false)
            }
            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty().take(1_500_000)
                runOnUiThread {
                    if (!response.isSuccessful) {
                        addMessage("Woulwe AI", "Сайт вернул HTTP ${response.code}.", false)
                        status.text = "Ошибка чтения сайта"; setBusy(false); return@runOnUiThread
                    }
                    val title = Regex("(?is)<title[^>]*>(.*?)</title>").find(raw)?.groupValues?.getOrNull(1)
                        ?.replace(Regex("<[^>]+>"), " ")?.trim()?.take(180) ?: target
                    val text = raw
                        .replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
                        .replace(Regex("(?i)<br\\s*/?>|</(p|div|h[1-6]|li|tr)>"), "\\n")
                        .replace(Regex("(?s)<[^>]+>"), " ")
                        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
                        .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
                        .replace(Regex("[ \\t\\r]+"), " ").replace(Regex("\\n\\s+"), "\\n")
                        .trim().take(10000)
                    if (text.isBlank()) {
                        addMessage("Woulwe AI", "Страница открылась, но читаемый текст не найден.", false)
                    } else {
                        addMessage("Сайт загружен на устройстве", "$title\n$target\n\n$text", false)
                        addMessage("Woulwe AI", "Текст страницы загружен прямо на телефон. Автоматический ИИ-анализ станет доступен после обучения и установки настоящих весов Woulwe; содержимое сайта не отправлялось стороннему ИИ.", false)
                    }
                    status.text = "Чтение сайта завершено"; setBusy(false)
                }
            }
        })
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "text/markdown", "text/csv", "application/json", "text/*"))
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 301)
    }

    @Deprecated("Compatible with the project's current minimum SDK")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 301 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val name = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else "файл" } ?: "файл"
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: throw IllegalArgumentException("Не удалось открыть файл.")
            if (text.isBlank()) throw IllegalArgumentException("Файл пустой.")
            pendingFileText = text.take(18000)
            input.setText("Проанализируй файл «$name»: сделай краткое содержание, выдели важное и объясни данные.\n\n$pendingFileText")
            input.setSelection(input.text.length); status.text = "Файл добавлен: $name"
            Toast.makeText(this, "Файл готов к анализу. Нажми отправить.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            AlertDialog.Builder(this).setTitle("Не удалось прочитать файл").setMessage("Выбери текстовый файл TXT, MD, CSV или JSON. PDF и Word пока нужно предварительно преобразовать в текст.").setPositiveButton("Понятно", null).show()
        }
    }

    private fun askImage() {
        val field = EditText(this).apply { hint = "Например: светящаяся фиолетово-синяя ИИ-сфера"; textSize = 15f; minLines = 3; gravity = Gravity.TOP; setTextColor(Color.WHITE); setHintTextColor(mutedColor); setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.rgb(31, 34, 53), dp(15).toFloat()) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(TextView(this).apply { text = "Опиши изображение как можно конкретнее."; textSize = 13f; setTextColor(mutedColor); setPadding(0, 0, 0, dp(10)) })
        box.addView(field, LinearLayout.LayoutParams(-1, dp(110)))
        AlertDialog.Builder(this).setTitle("Создать изображение").setView(box).setNegativeButton("Отмена", null)
            .setPositiveButton("Создать") { _, _ -> generateImage(field.text.toString().trim()) }.show()
    }

    private fun generateImage(prompt: String) {
        if (prompt.isBlank()) return
        addMessage("Вы · изображение", prompt, true)
        addMessage("Woulwe AI", "Локальная модель генерации изображений Woulwe ещё не обучена и не установлена. Приложение не обращается к OpenAI или другому облачному генератору.", false)
        status.text = "Ожидается локальная модель изображений"
    }

    private fun addImageMessage(bitmap: android.graphics.Bitmap) {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.START; setPadding(0, dp(8), 0, dp(8)) }
        block.addView(TextView(this).apply { text = "Woulwe AI · созданное изображение"; textSize = 12f; setTextColor(Color.rgb(143, 160, 255)); setPadding(dp(4), 0, 0, dp(7)) })
        val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; background = bg(Color.rgb(25, 28, 45), dp(18).toFloat()); clipToOutline = true; contentDescription = "Созданное изображение" }
        block.addView(image, LinearLayout.LayoutParams(-1, dp(310)))
        chat.addView(block, LinearLayout.LayoutParams(-1, -2)); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun modelEnabled(): Boolean =
        getSharedPreferences("woulwe_ai", MODE_PRIVATE).getBoolean("local_model_enabled", true)

    private fun updateModelStatus() {
        status.text = if (!modelEnabled()) "Локальная модель выключена"
        else "Woulwe Base 1.7B · веса ещё не установлены"
    }

    private fun showModelSettings() {
        val enabled = CheckBox(this).apply {
            text = "Использовать локальную модель Woulwe"
            setTextColor(Color.WHITE)
            isChecked = modelEnabled()
            textSize = 15f
        }
        val info = TextView(this).apply {
            text = "Модель должна работать на устройстве без OpenAI и облачных ИИ. Сейчас архитектура и обучение готовятся в репозитории, но обученных весов ещё нет. Приложение не будет скачивать фиктивную модель. Когда настоящий файл весов будет подготовлен, его можно будет установить один раз и хранить на телефоне."
            textSize = 13f
            setTextColor(mutedColor)
            setPadding(0, dp(14), 0, 0)
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(8))
            addView(enabled)
            addView(info)
        }
        AlertDialog.Builder(this)
            .setTitle("Модель Woulwe")
            .setView(panel)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                getSharedPreferences("woulwe_ai", MODE_PRIVATE).edit()
                    .putBoolean("local_model_enabled", enabled.isChecked).apply()
                updateModelStatus()
                Toast.makeText(this, if (enabled.isChecked) "Локальная модель включена" else "Локальная модель выключена", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showWelcome() {
        chat.removeAllViews()
        val welcome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18), dp(26), dp(18), dp(22)); background = bg(Color.rgb(20, 23, 40), dp(27).toFloat()) }
        val orb = TextView(this).apply { text = "✦"; textSize = 34f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = gradient(dp(28).toFloat()) }
        welcome.addView(orb, LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER; bottomMargin = dp(16) })
        welcome.addView(TextView(this).apply { text = "Чем займёмся?"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
        welcome.addView(TextView(this).apply { text = "Я помогу с идеями, учёбой, кодом, сайтами и данными."; textSize = 13.5f; gravity = Gravity.CENTER; setLineSpacing(dp(4).toFloat(), 1f); setTextColor(mutedColor); setPadding(0, dp(9), 0, dp(18)) })
        listOf(Pair("✧  Придумать идею", "Помоги придумать идею для проекта"), Pair("▤  Разобрать данные", "Помоги проанализировать данные"), Pair("{ }  Написать код", "Помоги написать код")).forEach { pair ->
            val item = TextView(this).apply {
                text = pair.first; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(226, 228, 247)); setPadding(dp(15), dp(14), dp(15), dp(14))
                background = bg(Color.rgb(31, 34, 53), dp(16).toFloat()); setOnClickListener { input.setText(pair.second); input.setSelection(input.text.length); input.requestFocus() }
            }
            welcome.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        chat.addView(welcome, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16); bottomMargin = dp(10) })
    }

    private fun addMessage(who: String, text: String, isUser: Boolean) {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (isUser) Gravity.END else Gravity.START; setPadding(0, dp(6), 0, dp(6)) }
        block.addView(TextView(this).apply { this.text = who; textSize = 11.5f; setTextColor(if (isUser) Color.rgb(164, 151, 255) else Color.rgb(133, 177, 255)); setPadding(dp(5), 0, dp(5), dp(5)) })
        val bubble = TextView(this).apply {
            this.text = text; textSize = 15.5f; setTextColor(Color.rgb(241, 242, 250)); setLineSpacing(dp(3).toFloat(), 1f); setPadding(dp(15), dp(12), dp(15), dp(12))
            background = bg(if (isUser) Color.rgb(70, 59, 151) else Color.rgb(26, 30, 47), dp(19).toFloat())
        }
        block.addView(bubble, LinearLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.82f).toInt(), -2))
        chat.addView(block, LinearLayout.LayoutParams(-1, -2)); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun resetChat() {
        while (messages.length() > 0) messages.remove(0)
        sessionId = null; pendingFileText = ""
        getSharedPreferences("woulwe_ai", MODE_PRIVATE).edit().remove("messages").apply()
        showWelcome(); status.text = "Новый чат"
    }

    private fun sendMessage() {
        if (busy) return
        var text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (pendingFileText.isNotBlank() && !text.contains(pendingFileText)) text += "\n\nСодержимое файла:\n$pendingFileText"
        pendingFileText = ""
        addMessage("Вы", text.take(5000), true); input.setText("")
        messages.put(JSONObject().put("role", "user").put("content", text.take(12000))); persistChat(); hideKeyboard()
        status.text = "Woulwe AI думает…"; setBusy(true); requestAssistantReply()
    }

    private fun requestAssistantReply() {
        // Privacy-first: never send chat content to a remote AI endpoint.
        // A real local runtime and trained Woulwe weights must be installed before inference can be enabled.
        runOnUiThread {
            val reply = if (!modelEnabled()) {
                "Локальная модель выключена. Открой меню ☰ → Настройки модели, чтобы включить её."
            } else {
                "Модель Woulwe Base 1.7B ещё не обучена и не установлена на устройстве. Сообщение осталось на телефоне и не отправлялось стороннему ИИ-провайдеру. Сначала нужно обучить настоящие веса модели и подключить локальный Android runtime."
            }
            messages.put(JSONObject().put("role", "assistant").put("content", reply))
            persistChat()
            addMessage("Woulwe AI · локальная модель", reply, false)
            status.text = if (modelEnabled()) "Ожидает установку локальной модели" else "Локальная модель выключена"
            setBusy(false)
        }
    }

    private fun setBusy(value: Boolean) { busy = value; send.isEnabled = !value; send.alpha = if (value) 0.55f else 1f; input.isEnabled = !value }
    private fun persistChat() { getSharedPreferences("woulwe_ai", MODE_PRIVATE).edit().putString("messages", messages.toString()).apply() }
    private fun restoreChat() {
        val saved = getSharedPreferences("woulwe_ai", MODE_PRIVATE).getString("messages", null)
        if (saved.isNullOrBlank()) { showWelcome(); return }
        try {
            val arr = JSONArray(saved)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i); val role = obj.optString("role"); val text = obj.optString("content")
                messages.put(obj)
                if (role == "user") addMessage("Вы", text.take(5000), true) else if (role == "assistant") addMessage("Woulwe AI", text, false)
            }
            if (messages.length() == 0) showWelcome()
        } catch (_: Exception) {
            getSharedPreferences("woulwe_ai", MODE_PRIVATE).edit().remove("messages").apply(); showWelcome()
        }
    }
    private fun hideKeyboard() {
        try { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } catch (_: Exception) {}
    }
}
