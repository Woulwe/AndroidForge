package com.woulwe.ai

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Minimal, premium-feeling native splash animation. */
class AiSplashView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particles = List(72) { i ->
        Particle(
            angle = i * 2.399963,
            orbit = 0.22 + ((i * 29) % 73) / 100.0,
            speed = 0.12 + ((i * 11) % 24) / 100.0,
            size = 0.7f + (i % 3) * 0.35f
        )
    }
    private var start = System.nanoTime()
    private var running = true

    private data class Particle(val angle: Double, val orbit: Double, val speed: Double, val size: Float)

    fun stop() {
        running = false
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val t = (System.nanoTime() - start) / 1_000_000_000.0
        val gather = ((t - 0.85) / 1.15).coerceIn(0.0, 1.0).toFloat()
        val logoFade = ((t - 1.55) / 0.65).coerceIn(0.0, 1.0).toFloat()
        val cx = w / 2f
        val cy = h * 0.43f
        val radius = min(w, h) * 0.245f

        canvas.drawColor(Color.rgb(5, 7, 15))

        // Restrained ambient lighting, like a polished software product intro.
        paint.shader = RadialGradient(
            cx, cy, radius * 2.45f,
            intArrayOf(Color.argb(38, 45, 74, 180), Color.argb(16, 93, 47, 160), Color.TRANSPARENT),
            floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 2.45f, paint)
        paint.shader = null

        // A thin, controlled energy field fades as it condenses into the mark.
        val fieldAlpha = (100f * (1f - gather)).toInt().coerceIn(0, 100)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(0.8f)
        paint.color = Color.argb(fieldAlpha, 102, 137, 255)
        canvas.drawCircle(cx, cy, radius * (1.05f + 0.035f * sin(t * 1.1).toFloat()), paint)
        paint.color = Color.argb((fieldAlpha * 0.55f).toInt(), 158, 94, 255)
        canvas.drawCircle(cx, cy, radius * 1.23f, paint)
        paint.style = Paint.Style.FILL

        // Fine light filaments slowly rotate, then disappear into the forming logo.
        for (i in 0..2) {
            val alpha = (65f * (1f - gather)).toInt().coerceIn(0, 65)
            canvas.save()
            canvas.rotate((t * (if (i == 1) -9f else 7f) + i * 54f).toFloat(), cx, cy)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(0.7f)
            paint.color = Color.argb(alpha, if (i == 1) 166 else 102, 143, 255)
            canvas.drawOval(
                RectF(cx - radius * 1.18f, cy - radius * (0.31f + i * 0.08f),
                    cx + radius * 1.18f, cy + radius * (0.31f + i * 0.08f)), paint
            )
            canvas.restore()
        }
        paint.style = Paint.Style.FILL

        // The atmospheric core contracts instead of popping away.
        val coreRadius = radius * (1f - gather * 0.83f)
        if (coreRadius > 0.5f) {
            paint.alpha = (190f * (1f - gather)).toInt().coerceIn(0, 190)
            paint.shader = RadialGradient(
                cx - coreRadius * 0.24f, cy - coreRadius * 0.28f, coreRadius * 1.6f,
                intArrayOf(Color.rgb(197, 211, 255), Color.rgb(87, 117, 232), Color.rgb(42, 31, 104), Color.TRANSPARENT),
                floatArrayOf(0f, 0.27f, 0.68f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, coreRadius, paint)
            paint.shader = null
            paint.alpha = 255
        }

        // Individual light points stream inward and settle on the geometric W.
        particles.forEachIndexed { index, p ->
            val a = p.angle + t * p.speed * if (index % 2 == 0) 1 else -1
            val orbitR = radius * (0.68 + p.orbit * 0.92).toFloat()
            val startX = cx + cos(a).toFloat() * orbitR
            val startY = cy + sin(a).toFloat() * orbitR * 0.55f
            val u = (index % 5) / 4f
            val markX = cx + (u - 0.5f) * radius * 1.12f
            val markY = cy + (if (index % 2 == 0) -0.27f else 0.30f) * radius
            val x = startX * (1f - gather) + markX * gather
            val y = startY * (1f - gather) + markY * gather
            paint.color = if (index % 4 == 0) Color.rgb(164, 139, 255) else Color.rgb(117, 164, 255)
            paint.alpha = ((70 + 95 * (0.5 + 0.5 * sin(t * 1.7 + index))) * (1f - gather * 0.78f)).toInt().coerceIn(0, 165)
            canvas.drawCircle(x, y, p.size * dp(1f), paint)
        }
        paint.alpha = 255

        // A single precise monogram emerges from the same gathered light.
        val markSize = radius * 0.82f
        val mark = Path().apply {
            moveTo(cx - markSize * 0.78f, cy - markSize * 0.40f)
            lineTo(cx - markSize * 0.39f, cy + markSize * 0.42f)
            lineTo(cx, cy - markSize * 0.08f)
            lineTo(cx + markSize * 0.39f, cy + markSize * 0.42f)
            lineTo(cx + markSize * 0.78f, cy - markSize * 0.40f)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = dp(2.4f)
        paint.shader = LinearGradient(
            cx - markSize, cy - markSize * 0.5f, cx + markSize, cy + markSize * 0.5f,
            Color.rgb(115, 165, 255), Color.rgb(187, 150, 255), Shader.TileMode.CLAMP
        )
        paint.alpha = (255f * gather).toInt().coerceIn(0, 255)
        canvas.drawPath(mark, paint)
        paint.shader = null
        paint.alpha = 255
        paint.style = Paint.Style.FILL

        // Clean typography, no playful tagline or bouncing loading dots.
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        paint.textSize = min(w * 0.073f, dp(28f))
        paint.color = Color.rgb(245, 247, 255)
        paint.alpha = (255f * logoFade).toInt().coerceIn(0, 255)
        canvas.drawText("Woulwe AI", cx, h * 0.685f, paint)

        paint.textSize = dp(10f)
        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        paint.color = Color.rgb(143, 153, 190)
        paint.alpha = (155f * logoFade).toInt().coerceIn(0, 155)
        canvas.drawText("INTELLIGENCE, REFINED", cx, h * 0.685f + dp(25f), paint)
        paint.alpha = 255

        if (running) postInvalidateOnAnimation()
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}