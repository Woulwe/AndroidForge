# Woulwe AI Architecture

Android App -> Woulwe API -> Auth/Sessions -> Memory -> Tool Registry -> Woulwe Inference -> Woulwe Model.

Supporting layers: training, tokenizer, preprocessing, evaluation, security, CI/CD and model storage.

Проект не содержит OpenAI API dependency.
