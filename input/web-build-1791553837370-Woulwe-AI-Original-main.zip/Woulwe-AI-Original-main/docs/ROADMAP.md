# Woulwe AI Roadmap

## Done
- Native Android client
- Core API
- Persistent session layer
- Tool registry
- Inference interface
- Training structure
- Dataset preprocessing
- Evaluation layer
- Security boundaries
- CI

## Next hardware-dependent stage
- Train Woulwe tokenizer
- Train base transformer
- Instruction tuning
- Safety evaluation
- Quantization
- GPU inference
- Model registry
