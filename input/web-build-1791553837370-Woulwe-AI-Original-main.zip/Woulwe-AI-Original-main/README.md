# Woulwe AI Original

Android application for the Woulwe AI assistant, with the work kept in this repository.

## Current direction

- No OpenAI SDK, API key, or remote AI inference is used by the Android chat.
- Website text is fetched and extracted on the Android device.
- Chat history stays in app-local storage.
- Settings include a local-model enable/disable toggle.
- The repository includes a custom Woulwe decoder architecture and a from-scratch training pipeline in `model-training/`.

## Important model status

The planned `Woulwe Base 1.7B` is an architecture/training target, not a completed pretrained model. Its trained weights are not included. The app intentionally does not pretend it can generate intelligent answers until real weights and a compatible Android inference runtime are available. Training a 1.7B model from scratch requires a large lawful dataset and substantial GPU compute.

## Build

- Package: `com.woulwe.ai`
- Min SDK: 24
- Target SDK: 35
- Codemagic config: `codemagic.yaml`
- GitHub Actions builds a debug APK and uploads it as an artifact.

See `model-training/README.md` for training data format, the from-scratch trainer, and compute requirements.

CI builds are triggered for pull requests so changes can be validated before merge.
