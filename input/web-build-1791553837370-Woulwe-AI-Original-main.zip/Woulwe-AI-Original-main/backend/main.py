import os
import uuid
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Woulwe AI Core", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    messages: list[dict[str, Any]] = Field(default_factory=list)
    session_id: str | None = None

@app.get("/")
def root():
    return {"name": "Woulwe AI Core", "status": "ok"}

@app.get("/health")
def health():
    return {"status": "ok", "configured": bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/v1/chat")
def chat(body: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="AI is not configured yet. Add OPENAI_API_KEY to the backend environment variables.",
        )

    cleaned_messages = []
    for item in body.messages[-60:]:
        role = str(item.get("role", "user"))
        content = item.get("content", "")
        if role not in ("system", "user", "assistant"):
            continue
        if not isinstance(content, str) or not content.strip():
            continue
        cleaned_messages.append({"role": role, "content": content[:30000]})

    if not cleaned_messages:
        raise HTTPException(status_code=400, detail="Please send a message.")

    try:
        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=cleaned_messages,
            temperature=0.7,
        )
        answer = response.choices[0].message.content or ""
        return {
            "session_id": body.session_id or str(uuid.uuid4()),
            "message": {"role": "assistant", "content": answer},
        }
    except Exception as exc:
        # Do not expose provider credentials or internal exception details to clients.
        raise HTTPException(status_code=502, detail="The AI provider request failed. Check the backend logs and API configuration.") from exc
