import importlib.util
import math
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("woulwe_model", ROOT / "woulwe_model.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
WoulweBaseModel = module.WoulweBaseModel


def test_tiny_model_forward_backward():
    torch.manual_seed(7)
    model = WoulweBaseModel(
        vocab_size=300, hidden_size=64, layers=2, heads=4,
        ff_size=128, max_seq_len=32, dropout=0.0
    )
    tokens = torch.randint(0, 300, (2, 16), dtype=torch.long)
    result = model(tokens, labels=tokens)
    assert result["logits"].shape == (2, 16, 300)
    assert result["loss"] is not None
    assert math.isfinite(float(result["loss"].item()))
    result["loss"].backward()
    assert any(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())


def test_rejects_sequence_over_limit():
    model = WoulweBaseModel(
        vocab_size=300, hidden_size=64, layers=2, heads=4,
        ff_size=128, max_seq_len=8, dropout=0.0
    )
    tokens = torch.randint(0, 300, (1, 9), dtype=torch.long)
    try:
        model(tokens)
    except ValueError as exc:
        assert "maximum length" in str(exc)
    else:
        raise AssertionError("Expected sequence-length validation to fail")
