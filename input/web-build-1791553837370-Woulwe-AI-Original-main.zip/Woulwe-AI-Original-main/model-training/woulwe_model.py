"""Original Woulwe decoder-only Transformer implementation (random initialization)."""
import math
import torch
from torch import nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x):
        scale = torch.rsqrt(x.float().pow(2).mean(-1, keepdim=True) + self.eps)
        return (x * scale.to(x.dtype)) * self.weight


def rotate_half(x):
    x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rope(q, k):
    length = q.shape[-2]
    dim = q.shape[-1]
    inv_freq = 1.0 / (10000 ** (torch.arange(0, dim, 2, device=q.device).float() / dim))
    positions = torch.arange(length, device=q.device).float()
    angles = torch.outer(positions, inv_freq)
    emb = torch.cat((angles, angles), dim=-1)
    cos = emb.cos()[None, None, :, :]
    sin = emb.sin()[None, None, :, :]
    return q * cos + rotate_half(q) * sin, k * cos + rotate_half(k) * sin


class WoulweAttention(nn.Module):
    def __init__(self, dim, heads, dropout=0.0):
        super().__init__()
        if dim % heads:
            raise ValueError("hidden_size must be divisible by attention_heads")
        self.heads = heads
        self.head_dim = dim // heads
        self.qkv = nn.Linear(dim, dim * 3, bias=False)
        self.out = nn.Linear(dim, dim, bias=False)
        self.dropout = dropout

    def forward(self, x):
        batch, length, dim = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(batch, length, self.heads, self.head_dim).transpose(1, 2)
        k = k.view(batch, length, self.heads, self.head_dim).transpose(1, 2)
        v = v.view(batch, length, self.heads, self.head_dim).transpose(1, 2)
        q, k = apply_rope(q, k)
        out = F.scaled_dot_product_attention(
            q, k, v, is_causal=True, dropout_p=self.dropout if self.training else 0.0
        )
        out = out.transpose(1, 2).contiguous().view(batch, length, dim)
        return self.out(out)


class SwiGLU(nn.Module):
    def __init__(self, dim, hidden_dim):
        super().__init__()
        self.gate = nn.Linear(dim, hidden_dim, bias=False)
        self.up = nn.Linear(dim, hidden_dim, bias=False)
        self.down = nn.Linear(hidden_dim, dim, bias=False)

    def forward(self, x):
        return self.down(F.silu(self.gate(x)) * self.up(x))


class WoulweBlock(nn.Module):
    def __init__(self, dim, heads, ff_dim, dropout=0.0):
        super().__init__()
        self.attn_norm = RMSNorm(dim)
        self.attn = WoulweAttention(dim, heads, dropout)
        self.ffn_norm = RMSNorm(dim)
        self.ffn = SwiGLU(dim, ff_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x + self.dropout(self.attn(self.attn_norm(x)))
        x = x + self.dropout(self.ffn(self.ffn_norm(x)))
        return x


class WoulweBaseModel(nn.Module):
    """Woulwe Base decoder model; weights are initialized from scratch."""

    def __init__(self, vocab_size, hidden_size=2048, layers=24, heads=16,
                 ff_size=8192, max_seq_len=2048, dropout=0.0):
        super().__init__()
        self.config = {
            "model_name": "Woulwe-Base-1.7B",
            "vocab_size": vocab_size,
            "hidden_size": hidden_size,
            "layers": layers,
            "heads": heads,
            "ff_size": ff_size,
            "max_seq_len": max_seq_len,
            "architecture": "WoulweDecoder-RMSNorm-RoPE-SwiGLU-v1",
        }
        self.embedding = nn.Embedding(vocab_size, hidden_size)
        self.blocks = nn.ModuleList([
            WoulweBlock(hidden_size, heads, ff_size, dropout) for _ in range(layers)
        ])
        self.final_norm = RMSNorm(hidden_size)
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)
        self.lm_head.weight = self.embedding.weight
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids, labels=None):
        if input_ids.shape[1] > self.config["max_seq_len"]:
            raise ValueError("Input sequence exceeds configured maximum length")
        x = self.embedding(input_ids)
        for block in self.blocks:
            x = block(x)
        logits = self.lm_head(self.final_norm(x))
        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits[:, :-1, :].contiguous().view(-1, logits.size(-1)),
                labels[:, 1:].contiguous().view(-1),
            )
        return {"logits": logits, "loss": loss}

    def parameter_count(self):
        return sum(p.numel() for p in self.parameters())
