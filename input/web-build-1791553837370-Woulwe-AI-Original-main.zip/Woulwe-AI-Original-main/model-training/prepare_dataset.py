#!/usr/bin/env python3
"""Prepare a deduplicated plain-text corpus for Woulwe from licensed local files.

Supported inputs: .txt, .md, .jsonl. JSONL records must contain a string field
named "text" or "content". The script never downloads data.
"""
import argparse
import hashlib
import json
import random
from pathlib import Path


def read_documents(path: Path):
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md"}:
        text = path.read_text(encoding="utf-8", errors="replace").strip()
        if text:
            yield text
    elif suffix == ".jsonl":
        with path.open("r", encoding="utf-8", errors="replace") as stream:
            for line_number, line in enumerate(stream, 1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{path}:{line_number}: invalid JSONL: {exc}") from exc
                if not isinstance(row, dict):
                    continue
                text = row.get("text", row.get("content", ""))
                if isinstance(text, str) and text.strip():
                    yield text.strip()


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="File or directory containing licensed text")
    parser.add_argument("--out", required=True, help="Output directory for train.txt and valid.txt")
    parser.add_argument("--valid-ratio", type=float, default=0.02)
    parser.add_argument("--min-chars", type=int, default=40)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--license-note", required=True, help="Describe the rights/license for this corpus")
    args = parser.parse_args()

    if not 0.0 < args.valid_ratio < 0.5:
        parser.error("--valid-ratio must be greater than 0 and less than 0.5")
    if args.min_chars < 1:
        parser.error("--min-chars must be positive")
    if not args.license_note.strip():
        parser.error("--license-note is required; use only material you have rights to use")

    source = Path(args.input)
    if not source.exists():
        parser.error(f"Input path does not exist: {source}")
    files = [source] if source.is_file() else sorted(
        p for p in source.rglob("*") if p.is_file() and p.suffix.lower() in {".txt", ".md", ".jsonl"}
    )
    documents, seen = [], set()
    for path in files:
        for text in read_documents(path):
            text = "\n".join(line.rstrip() for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")).strip()
            if len(text) < args.min_chars:
                continue
            key = digest(text)
            if key not in seen:
                seen.add(key)
                documents.append((path.name, text, key))

    if len(documents) < 2:
        parser.error(f"Need at least 2 unique documents after filtering; found {len(documents)}")

    random.Random(args.seed).shuffle(documents)
    valid_count = max(1, round(len(documents) * args.valid_ratio))
    valid_docs, train_docs = documents[:valid_count], documents[valid_count:]
    if not train_docs:
        parser.error("Not enough documents to create both train and validation sets")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    train_text = "\n\n".join(item[1] for item in train_docs) + "\n"
    valid_text = "\n\n".join(item[1] for item in valid_docs) + "\n"
    (out / "train.txt").write_text(train_text, encoding="utf-8")
    (out / "valid.txt").write_text(valid_text, encoding="utf-8")
    manifest = {
        "format_version": 1,
        "source_files": [str(p) for p in files],
        "license_note": args.license_note.strip(),
        "seed": args.seed,
        "valid_ratio_requested": args.valid_ratio,
        "min_chars": args.min_chars,
        "unique_documents": len(documents),
        "train_documents": len(train_docs),
        "valid_documents": len(valid_docs),
        "train_characters": len(train_text),
        "valid_characters": len(valid_text),
        "train_sha256": digest(train_text),
        "valid_sha256": digest(valid_text),
        "note": "Verify source rights and privacy manually; this manifest is not legal advice."
    }
    (out / "dataset-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ("unique_documents", "train_documents", "valid_documents", "train_characters", "valid_characters", "train_sha256", "valid_sha256")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
