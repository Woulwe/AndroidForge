#!/usr/bin/env python3
"""Train original Woulwe decoder weights from random initialization."""
import argparse
import json
import math
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader
from tokenizers import Tokenizer, models, pre_tokenizers, trainers
from woulwe_model import WoulweBaseModel


class TextBlocks(Dataset):
    def __init__(self, path, tokenizer, block_size):
        ids = tokenizer.encode(Path(path).read_text(encoding="utf-8")).ids
        self.blocks = [
            ids[i:i + block_size]
            for i in range(0, len(ids) - block_size + 1, block_size)
        ]

    def __len__(self):
        return len(self.blocks)

    def __getitem__(self, index):
        return torch.tensor(self.blocks[index], dtype=torch.long)


def build_tokenizer(train_path, output, vocab_size):
    target = output / "tokenizer.json"
    if not target.exists():
        tokenizer = Tokenizer(models.BPE(unk_token="[UNK]"))
        tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
        trainer = trainers.BpeTrainer(
            vocab_size=vocab_size,
            special_tokens=["[UNK]", "[BOS]", "[EOS]", "[PAD]"],
            initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        )
        tokenizer.train([str(train_path)], trainer)
        tokenizer.save(str(target))
    return Tokenizer.from_file(str(target))


@torch.no_grad()
def evaluate(model, loader, device, max_batches=50):
    model.eval()
    losses = []
    for index, batch in enumerate(loader):
        if index >= max_batches:
            break
        batch = batch.to(device)
        losses.append(float(model(batch, labels=batch)["loss"].item()))
    model.train()
    return sum(losses) / max(1, len(losses))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--train", required=True)
    parser.add_argument("--valid", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    train_path, valid_path, output = Path(args.train), Path(args.valid), Path(args.out)
    for path in (train_path, valid_path):
        if not path.is_file():
            raise SystemExit(f"Required dataset does not exist: {path}")

    output.mkdir(parents=True, exist_ok=True)
    block_size = int(config.get("block_size", 1024))
    tokenizer = build_tokenizer(train_path, output, int(config.get("tokenizer_vocab_size", 32000)))
    train_ds = TextBlocks(train_path, tokenizer, block_size)
    valid_ds = TextBlocks(valid_path, tokenizer, block_size)
    if not len(train_ds) or not len(valid_ds):
        raise SystemExit("Train and validation files each need at least one full token block.")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = WoulweBaseModel(
        vocab_size=tokenizer.get_vocab_size(),
        hidden_size=int(config["n_embd"]),
        layers=int(config["n_layer"]),
        heads=int(config["n_head"]),
        ff_size=int(config.get("n_inner", 4 * int(config["n_embd"]))),
        max_seq_len=int(config.get("n_positions", block_size)),
        dropout=float(config.get("dropout", 0.0)),
    ).to(device)
    print(f"Initialized Woulwe weights from scratch: {model.parameter_count():,} parameters on {device}")
    train_loader = DataLoader(train_ds, batch_size=int(config.get("batch_size", 1)), shuffle=True)
    valid_loader = DataLoader(valid_ds, batch_size=1)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config.get("learning_rate", 2e-4)),
        weight_decay=float(config.get("weight_decay", 0.1)),
    )
    max_steps = int(config.get("max_steps", 100000))
    accumulation = int(config.get("gradient_accumulation_steps", 32))
    warmup = int(config.get("warmup_steps", 2000))
    log_steps = int(config.get("logging_steps", 10))
    save_steps = int(config.get("save_steps", 1000))
    eval_steps = int(config.get("eval_steps", 500))
    step = 0
    optimizer.zero_grad(set_to_none=True)
    while step < max_steps:
        for batch_index, batch in enumerate(train_loader):
            batch = batch.to(device)
            result = model(batch, labels=batch)
            (result["loss"] / accumulation).backward()
            is_accumulation_boundary = (batch_index + 1) % accumulation == 0
            is_last_batch = (batch_index + 1) == len(train_loader)
            if not is_accumulation_boundary and not is_last_batch:
                continue
            # Correct the gradient scale for a short final accumulation group.
            remainder = (batch_index + 1) % accumulation
            if is_last_batch and remainder:
                correction = accumulation / remainder
                for parameter in model.parameters():
                    if parameter.grad is not None:
                        parameter.grad.mul_(correction)
            step += 1
            if warmup and step <= warmup:
                for group in optimizer.param_groups:
                    group["lr"] = float(config.get("learning_rate", 2e-4)) * step / warmup
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            if step % log_steps == 0:
                print(json.dumps({"step": step, "train_loss": float(result["loss"].item())}))
            if step % eval_steps == 0:
                val_loss = evaluate(model, valid_loader, device)
                print(json.dumps({"step": step, "valid_loss": val_loss,
                                  "perplexity": math.exp(min(val_loss, 20.0))}))
            if step % save_steps == 0:
                torch.save({"step": step, "config": model.config, "model": model.state_dict()},
                           output / f"checkpoint-{step}.pt")
            if step >= max_steps:
                break

    torch.save({"step": step, "config": model.config, "model": model.state_dict()},
               output / "woulwe-base-final.pt")
    tokenizer.save(str(output / "tokenizer.json"))
    (output / "model-config.json").write_text(
        json.dumps(model.config, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Finished training. Model and tokenizer saved to {output}")


if __name__ == "__main__":
    main()
